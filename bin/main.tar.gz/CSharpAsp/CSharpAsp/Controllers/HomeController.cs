﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;

namespace CSharpAsp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var people = this.createInitList();

            return View(people);
        }
        private IEnumerable<Models.Persons> createInitList()
        {
            int i = 0;
            var list = new List<Models.Persons>();
            foreach (string x in new string[] {"Adam", "Bob", "Carl"})
            {
                var model = new Models.Persons() { Id = i, Name = x, Age = i };
                list.Add(model);
                i++;
            }
            return list;
        }
    }
}
